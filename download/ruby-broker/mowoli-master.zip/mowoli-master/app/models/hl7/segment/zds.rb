# Additional Identification Information
module HL7
  module Segment
    class ZDS < Base
      field :study_instance_uid
    end
  end
end
